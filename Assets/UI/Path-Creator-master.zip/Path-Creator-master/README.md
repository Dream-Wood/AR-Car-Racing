# Path-Creator

[Watch overview video](https://www.youtube.com/watch?v=saAQNRSYU9k)

[Read the documentation](https://docs.google.com/document/d/1-FInNfD2GC-fVXO6KyeTSp9OSKst5AzLxDaBRb69b-Y/edit?usp=sharing)

[Download from asset store](https://assetstore.unity.com/packages/tools/utilities/b-zier-path-creator-136082)

![Path Creator](https://i.imgur.com/xqTCNWK.png)
